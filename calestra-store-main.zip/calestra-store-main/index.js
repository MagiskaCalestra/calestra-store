
import React from "react";
import ReactDOM from "react-dom";
import Drop01Page from "./Drop01Page";

ReactDOM.render(
  <React.StrictMode>
    <Drop01Page />
  </React.StrictMode>,
  document.getElementById("root")
);
